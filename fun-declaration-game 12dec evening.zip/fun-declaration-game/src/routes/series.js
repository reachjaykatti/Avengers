
import express from 'express';
import { getDb } from '../config/db.js';
import {
  hasDeadlinePassed,
  hasMatchStarted,
  nowUtcISO,
  cutoffTimeUtc,
  toIst,
} from '../utils/time.js';

const router = express.Router();

/* -------------------------------
   My Series (the ones user is in)
--------------------------------- */
router.get('/', async (req, res) => {
  const db = await getDb();
  const seriesAllowed = await db.all(
    `
    SELECT s.* FROM series s
    JOIN series_members sm ON sm.series_id = s.id
    WHERE sm.user_id = ?
    ORDER BY s.start_date_utc DESC
  `,
    [req.session.user.id]
  );

  res.render('series/index', { title: 'My Series', series: seriesAllowed });
});

/* --------------------------------
   Series Detail + Quick Declare
   (precompute IST + cutoff for countdown)
---------------------------------- */
router.get('/:id', async (req, res) => {
  const db = await getDb();

  const series = await db.get('SELECT * FROM series WHERE id = ?', [req.params.id]);
  if (!series) return res.status(404).send('Series not found');

  const matches = await db.all(
    'SELECT * FROM matches WHERE series_id = ? ORDER BY start_time_utc ASC',
    [req.params.id]
  );

  // Precompute IST strings and flags the view needs
  const computed = [];
  for (const m of matches) {
    const deadlinePassed = hasDeadlinePassed(m.start_time_utc, m.cutoff_minutes_before);
    const hasStartedByTime = hasMatchStarted(m.start_time_utc);
    const startedFlag = m.status !== 'scheduled' || hasStartedByTime;
    const lockedForPrediction = deadlinePassed || m.status !== 'scheduled';

    const myPred = await db.get(
      'SELECT * FROM predictions WHERE match_id = ? AND user_id = ?',
      [m.id, req.session.user.id]
    );

    const startIstStr = toIst(m.start_time_utc).format('YYYY-MM-DD HH:mm');
    const cutoffUtcIso = cutoffTimeUtc(m.start_time_utc, m.cutoff_minutes_before);
    const cutoffIstStr = toIst(cutoffUtcIso).format('YYYY-MM-DD HH:mm');

    computed.push({
      ...m,
      deadlinePassed,
      hasStartedByTime,
      startedFlag,
      lockedForPrediction,
      myPred,
      startIstStr,
      cutoffUtcIso, // used for countdown
      cutoffIstStr, // display for cutoff in IST
    });
  }

  // Also precompute series start/end in IST for header display (if present)
  const seriesStartIstStr = series.start_date_utc
    ? toIst(series.start_date_utc).format('YYYY-MM-DD HH:mm')
    : '';
  const seriesEndIstStr = series.end_date_utc
    ? toIst(series.end_date_utc).format('YYYY-MM-DD HH:mm')
    : '';

  res.render('series/detail', {
    title: series.name,
    series,
    seriesStartIstStr,
    seriesEndIstStr,
    matches: computed,
  });
});

/* --------------------------------
   Submit/Update Prediction
   (blocked after cutoff or if status != scheduled)
---------------------------------- */
router.post('/:id/matches/:matchId/predict', async (req, res) => {
  const db = await getDb();
  const match = await db.get(
    'SELECT * FROM matches WHERE id = ? AND series_id = ?',
    [req.params.matchId, req.params.id]
  );
  if (!match) return res.status(404).send('Match not found');

  const { team } = req.body; // 'A' or 'B'
  const deadlinePassed = hasDeadlinePassed(
    match.start_time_utc,
    match.cutoff_minutes_before
  );
  const lockedForPrediction = deadlinePassed || match.status !== 'scheduled';
  if (lockedForPrediction) return res.status(400).send('Prediction locked');

  try {
    await db.run(
      'INSERT INTO predictions (match_id, user_id, predicted_team, predicted_at_utc, locked) VALUES (?,?,?,?,?)',
      [req.params.matchId, req.session.user.id, team, nowUtcISO(), 1]
    );
  } catch {
    await db.run(
      'UPDATE predictions SET predicted_team = ?, predicted_at_utc = ? WHERE match_id = ? AND user_id = ?',
      [team, nowUtcISO(), req.params.matchId, req.session.user.id]
    );
  }
  res.redirect(`/series/${req.params.id}`);
});

/* --------------------------------
   Match Detail (user)
   - shows all declarations after cutoff or started
   - shows probable points with team-wise player names
   - shows final result + my points after completion
---------------------------------- */
router.get('/:id/matches/:matchId', async (req, res) => {
  const db = await getDb();

  const match = await db.get(
    'SELECT * FROM matches WHERE id = ? AND series_id = ?',
    [req.params.matchId, req.params.id]
  );
  if (!match) return res.status(404).send('Match not found');

  const series = await db.get('SELECT * FROM series WHERE id = ?', [req.params.id]);
  if (!series) return res.status(404).send('Series not found');

  const myPred = await db.get(
    'SELECT * FROM predictions WHERE match_id = ? AND user_id = ?',
    [req.params.matchId, req.session.user.id]
  );

  const deadlinePassed = hasDeadlinePassed(
    match.start_time_utc,
    match.cutoff_minutes_before
  );
  const hasStartedByTime = hasMatchStarted(match.start_time_utc);
  const startedFlag = match.status !== 'scheduled' || hasStartedByTime;
  const showAll = deadlinePassed || startedFlag;

  // Reveal all predictions (names) after cutoff or when started
  let allPreds = [];
  if (showAll) {
    allPreds = await db.all(
      'SELECT p.*, u.display_name FROM predictions p JOIN users u ON p.user_id = u.id WHERE match_id = ?',
      [req.params.matchId]
    );
  }

  // Members count
  const membersCountRow = await db.get(
    'SELECT COUNT(*) as c FROM series_members WHERE series_id = ?',
    [req.params.id]
  );
  const membersCount =
    membersCountRow && typeof membersCountRow.c === 'number'
      ? membersCountRow.c
      : 0;

  // Probable points + names per team (only if not completed/washed_out)
  let probable = null;
  let probableNames = null; // { A: [...names], B: [...names] }
  if (showAll && match.status !== 'completed' && match.status !== 'washed_out') {
    const preds = await db.all(
      'SELECT p.*, u.display_name FROM predictions p JOIN users u ON p.user_id = u.id WHERE match_id = ?',
      [req.params.matchId]
    );

    const aSide = preds.filter((p) => p.predicted_team === 'A');
    const bSide = preds.filter((p) => p.predicted_team === 'B');

    const aCount = aSide.length;
    const bCount = bSide.length;

    const missed = Math.max(0, membersCount - preds.length);
    const entry = match.entry_points;

    const potIfA = (bCount + missed) * entry;
    const potIfB = (aCount + missed) * entry;

    probable = {
      A: {
        winners: aCount,
        losers: bCount + missed,
        perWinner: aCount ? potIfA / aCount : 0,
        totalPot: potIfA,
      },
      B: {
        winners: bCount,
        losers: aCount + missed,
        perWinner: bCount ? potIfB / bCount : 0,
        totalPot: potIfB,
      },
    };

    probableNames = {
      A: aSide.map((p) => p.display_name).sort((x, y) => x.localeCompare(y)),
      B: bSide.map((p) => p.display_name).sort((x, y) => x.localeCompare(y)),
    };
  }

  // Precompute IST for header
  const matchStartIstStr = toIst(match.start_time_utc).format('YYYY-MM-DD HH:mm');

  // My points for this match (after completion)
  let myMatchPoints = null;
  if (match.status === 'completed') {
    const row = await db.get(
      'SELECT COALESCE(SUM(points),0) as pts FROM points_ledger WHERE user_id = ? AND match_id = ?',
      [req.session.user.id, match.id]
    );
    myMatchPoints = row ? row.pts : 0;
  }

  res.render('series/match', {
    title: match.name,
    series,
    match: { ...match, startIstStr: matchStartIstStr },
    myPred,
    allPreds,
    membersCount,
    probable,
    probableNames,
    deadlinePassed,
    startedFlag,
    showAll,
    myMatchPoints,
  });
});

export default router;
