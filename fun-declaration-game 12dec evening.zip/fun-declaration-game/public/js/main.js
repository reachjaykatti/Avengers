
// Back link + Theme toggle + Double confirm for declare + IST helper
(function () {
  function go(url) { window.location.href = url; }

  // ---- Back behavior ----
  function backAction() {
    var el = document.querySelector('.js-back');
    var prev = el ? el.getAttribute('data-prev') : '';
    if (prev && prev !== location.href) { go(prev); return; }
    try {
      if (document.referrer && document.referrer !== location.href && history.length > 1) {
        const before = location.href;
        history.back();
        setTimeout(function () {
          if (location.href === before) go(window.fdHomeUrl || '/dashboard');
        }, 350);
        return;
      }
    } catch(e) {}
    go(window.fdHomeUrl || '/dashboard');
  }

  // ---- Theme toggle ----
  function applyTheme(t){ document.body.setAttribute('data-theme', t); localStorage.setItem('fdTheme', t); }
  function toggleTheme(){ var cur=document.body.getAttribute('data-theme')||'dark'; applyTheme(cur==='dark'?'light':'dark'); }
  var saved=localStorage.getItem('fdTheme'); if(saved) applyTheme(saved);

  // ---- Double confirm on quick declare buttons ----
  function handleDeclareButton(t) {
    const teamName = t.getAttribute('data-teamname');
    const formId   = t.getAttribute('data-form');
    const form     = document.getElementById(formId);
    if (!form) return;
    if (!confirm('Confirm pick: ' + teamName + ' ?')) return;
    if (!confirm('Are you sure? This will lock your pick at this time.')) return;
    form.submit();
  }

  // ---- IST → UTC helper ----
  // Expects IST string 'YYYY-MM-DD HH:mm'
  function istToUtcIso(istStr) {
    if (!istStr) return '';
    var m = istStr.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})$/);
    if (!m) return '';
    var y=+m[1], mo=+m[2]-1, d=+m[3], hh=+m[4], mm=+m[5];
    // Create a UTC date that corresponds to IST - 5:30
    // i.e., UTC = IST - 05:30
    var dateUtc = new Date(Date.UTC(y, mo, d, hh, mm));
    dateUtc.setMinutes(dateUtc.getMinutes() - 330); // subtract 5h30m
    return dateUtc.toISOString();
  }

  // When submitting admin match forms, auto-convert IST if present
  function wireIstForms() {
    document.querySelectorAll('form[data-ist-form="1"]').forEach(function(form){
      form.addEventListener('submit', function(e){
        var istInput  = form.querySelector('input[name="start_time_ist"]');
        var utcInput  = form.querySelector('input[name="start_time_utc"]');
        if (istInput && istInput.value && utcInput && !utcInput.value) {
          var iso = istToUtcIso(istInput.value.trim());
          if (!iso) {
            alert('Invalid IST format. Use YYYY-MM-DD HH:mm (24-hour).');
            e.preventDefault();
            return;
          }
          utcInput.value = iso;
        }
      });
    });
  }

  // ---- Event delegation ----
  document.addEventListener('click', function (e) {
    const t = e.target;

    if (t && t.classList.contains('js-back')) { e.preventDefault(); backAction(); }
    if (t && t.classList.contains('js-theme-toggle')) { e.preventDefault(); toggleTheme(); }
    if (t && t.classList.contains('js-declare')) { e.preventDefault(); handleDeclareButton(t); }
  });

  // Init IST form wiring after DOM loads
  document.addEventListener('DOMContentLoaded', wireIstForms);
})();
